﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome3
{
    public partial class Form1 : Form
    {
        DataTable dtUser = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bt_register_Click(object sender, EventArgs e)
        {
            gb_mainpage.Visible = false;
            gb_Register.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtUser.Columns.Add("Username");
            dtUser.Columns.Add("Password");
            dtUser.Columns.Add("Balance");
            int currency = Convert.ToInt32(lb_number.Text);
            lb_number.Text = currency.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            lb_numdepo.Text = currency.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
<<<<<<< HEAD
=======
            dataGridView1.DataSource = dtUser;
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a

        }

        private void button_register_Click(object sender, EventArgs e)
        {
            MessageBox.Show("User Regisetered Succesfully");
            dtUser.Rows.Add(tb_username2.Text, tb_password2.Text, 0);
            gb_Register.Visible = false;
            gb_mainpage.Visible=true;
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
         
<<<<<<< HEAD
=======
            int indexdata;
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            for (int i = 0; i < dtUser.Rows.Count; i++)
            {
                if (tb_username.Text.Contains(dtUser.Rows[i][0].ToString()) && tb_password.Text.Contains(dtUser.Rows[i][1].ToString()))
                {
                    MessageBox.Show("Login Succesful");
                    gb_mainpage.Visible = false;
                    gb_balance.Visible = true;
                }
                else 
                {
                    MessageBox.Show("Login Unsuccesful");
                    //MessageBox.Show("Reason: " + exception.toString());
                }
            }

        }

        private void bt_deposit_Click(object sender, EventArgs e)
        {
            gb_deposit.Visible = true;
            gb_balance.Visible = false;
        }

        private void bt_deposit2_Click(object sender, EventArgs e)
        {
<<<<<<< HEAD
            gb_deposit.Visible = false;
            gb_balance.Visible = true;
        }

        private void bt_withdraw_Click(object sender, EventArgs e)
        {
            gb_withdraw.Visible = true;
            gb_balance.Visible=false;
        }

        private void bt_withdraw2_Click(object sender, EventArgs e)
        {
            gb_withdraw.Visible = false;
=======
            dtUser.Rows.
           // gb_deposit.Visible = false;
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            gb_balance.Visible = true;
        }
    }
}
