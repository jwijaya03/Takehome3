﻿namespace Takehome3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Title = new System.Windows.Forms.Label();
            this.lb_username = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.bt_login = new System.Windows.Forms.Button();
            this.gb_mainpage = new System.Windows.Forms.GroupBox();
            this.bt_register = new System.Windows.Forms.Button();
            this.gb_Register = new System.Windows.Forms.GroupBox();
            this.tb_username2 = new System.Windows.Forms.TextBox();
            this.button_register = new System.Windows.Forms.Button();
            this.tb_password2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.gb_balance = new System.Windows.Forms.GroupBox();
            this.bt_withdraw = new System.Windows.Forms.Button();
            this.bt_deposit = new System.Windows.Forms.Button();
            this.lb_number = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.bt_logout = new System.Windows.Forms.Button();
            this.gb_deposit = new System.Windows.Forms.GroupBox();
            this.lb_deposit = new System.Windows.Forms.Label();
            this.tb_depo = new System.Windows.Forms.TextBox();
            this.bt_deposit2 = new System.Windows.Forms.Button();
            this.gb_withdraw = new System.Windows.Forms.GroupBox();
<<<<<<< HEAD
            this.bt_withdraw2 = new System.Windows.Forms.Button();
=======
            this.button1 = new System.Windows.Forms.Button();
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lb_withdraw = new System.Windows.Forms.Label();
            this.lb_numdepo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
<<<<<<< HEAD
=======
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.gb_mainpage.SuspendLayout();
            this.gb_Register.SuspendLayout();
            this.gb_balance.SuspendLayout();
            this.gb_deposit.SuspendLayout();
            this.gb_withdraw.SuspendLayout();
<<<<<<< HEAD
=======
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.SuspendLayout();
            // 
            // lb_Title
            // 
            this.lb_Title.AutoSize = true;
            this.lb_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Title.Location = new System.Drawing.Point(200, 27);
            this.lb_Title.Name = "lb_Title";
            this.lb_Title.Size = new System.Drawing.Size(133, 32);
            this.lb_Title.TabIndex = 0;
            this.lb_Title.Text = "UC Bank";
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(14, 33);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(73, 16);
            this.lb_username.TabIndex = 1;
            this.lb_username.Text = "Username:";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(14, 67);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(70, 16);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "Password:";
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(93, 33);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(126, 22);
            this.tb_username.TabIndex = 3;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(93, 61);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(126, 22);
            this.tb_password.TabIndex = 4;
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(104, 89);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(94, 29);
            this.bt_login.TabIndex = 5;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // gb_mainpage
            // 
            this.gb_mainpage.Controls.Add(this.bt_register);
            this.gb_mainpage.Controls.Add(this.tb_username);
            this.gb_mainpage.Controls.Add(this.bt_login);
            this.gb_mainpage.Controls.Add(this.tb_password);
            this.gb_mainpage.Controls.Add(this.lb_username);
            this.gb_mainpage.Controls.Add(this.lb_password);
            this.gb_mainpage.Location = new System.Drawing.Point(127, 105);
            this.gb_mainpage.Name = "gb_mainpage";
            this.gb_mainpage.Size = new System.Drawing.Size(264, 168);
            this.gb_mainpage.TabIndex = 6;
            this.gb_mainpage.TabStop = false;
            // 
            // bt_register
            // 
            this.bt_register.Location = new System.Drawing.Point(104, 124);
            this.bt_register.Name = "bt_register";
            this.bt_register.Size = new System.Drawing.Size(94, 29);
            this.bt_register.TabIndex = 6;
            this.bt_register.Text = "Register";
            this.bt_register.UseVisualStyleBackColor = true;
            this.bt_register.Click += new System.EventHandler(this.bt_register_Click);
            // 
            // gb_Register
            // 
            this.gb_Register.Controls.Add(this.tb_username2);
            this.gb_Register.Controls.Add(this.button_register);
            this.gb_Register.Controls.Add(this.tb_password2);
            this.gb_Register.Controls.Add(this.label2);
            this.gb_Register.Controls.Add(this.label3);
            this.gb_Register.Location = new System.Drawing.Point(139, 100);
            this.gb_Register.Name = "gb_Register";
            this.gb_Register.Size = new System.Drawing.Size(215, 162);
            this.gb_Register.TabIndex = 7;
            this.gb_Register.TabStop = false;
            this.gb_Register.Visible = false;
            // 
            // tb_username2
            // 
            this.tb_username2.Location = new System.Drawing.Point(80, 29);
            this.tb_username2.Name = "tb_username2";
            this.tb_username2.Size = new System.Drawing.Size(126, 22);
            this.tb_username2.TabIndex = 9;
            this.tb_username2.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // button_register
            // 
            this.button_register.Location = new System.Drawing.Point(91, 85);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(94, 29);
            this.button_register.TabIndex = 11;
            this.button_register.Text = "Register";
            this.button_register.UseVisualStyleBackColor = true;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // tb_password2
            // 
            this.tb_password2.Location = new System.Drawing.Point(80, 57);
            this.tb_password2.Name = "tb_password2";
            this.tb_password2.Size = new System.Drawing.Size(126, 22);
            this.tb_password2.TabIndex = 10;
            this.tb_password2.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Password:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // gb_balance
            // 
            this.gb_balance.Controls.Add(this.bt_withdraw);
            this.gb_balance.Controls.Add(this.bt_deposit);
            this.gb_balance.Controls.Add(this.lb_number);
            this.gb_balance.Controls.Add(this.lb_balance);
            this.gb_balance.Controls.Add(this.bt_logout);
            this.gb_balance.Location = new System.Drawing.Point(155, 97);
            this.gb_balance.Name = "gb_balance";
            this.gb_balance.Size = new System.Drawing.Size(258, 195);
            this.gb_balance.TabIndex = 8;
            this.gb_balance.TabStop = false;
            this.gb_balance.Visible = false;
            // 
            // bt_withdraw
            // 
            this.bt_withdraw.Location = new System.Drawing.Point(99, 128);
            this.bt_withdraw.Name = "bt_withdraw";
            this.bt_withdraw.Size = new System.Drawing.Size(88, 23);
            this.bt_withdraw.TabIndex = 4;
            this.bt_withdraw.Text = "Withdraw";
            this.bt_withdraw.UseVisualStyleBackColor = true;
<<<<<<< HEAD
            this.bt_withdraw.Click += new System.EventHandler(this.bt_withdraw_Click);
=======
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            // 
            // bt_deposit
            // 
            this.bt_deposit.Location = new System.Drawing.Point(99, 99);
            this.bt_deposit.Name = "bt_deposit";
            this.bt_deposit.Size = new System.Drawing.Size(88, 23);
            this.bt_deposit.TabIndex = 3;
            this.bt_deposit.Text = "Deposit";
            this.bt_deposit.UseVisualStyleBackColor = true;
            this.bt_deposit.Click += new System.EventHandler(this.bt_deposit_Click);
            // 
            // lb_number
            // 
            this.lb_number.AutoSize = true;
            this.lb_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_number.Location = new System.Drawing.Point(109, 73);
            this.lb_number.Name = "lb_number";
            this.lb_number.Size = new System.Drawing.Size(20, 22);
            this.lb_number.TabIndex = 2;
            this.lb_number.Text = "0";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(21, 73);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(57, 16);
            this.lb_balance.TabIndex = 1;
            this.lb_balance.Text = "Balance";
            // 
            // bt_logout
            // 
            this.bt_logout.Location = new System.Drawing.Point(153, 21);
            this.bt_logout.Name = "bt_logout";
            this.bt_logout.Size = new System.Drawing.Size(75, 23);
            this.bt_logout.TabIndex = 0;
            this.bt_logout.Text = "Log Out";
            this.bt_logout.UseVisualStyleBackColor = true;
            // 
            // gb_deposit
            // 
            this.gb_deposit.Controls.Add(this.bt_deposit2);
            this.gb_deposit.Controls.Add(this.tb_depo);
            this.gb_deposit.Controls.Add(this.lb_deposit);
<<<<<<< HEAD
            this.gb_deposit.Location = new System.Drawing.Point(460, 96);
=======
            this.gb_deposit.Location = new System.Drawing.Point(526, 84);
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.gb_deposit.Name = "gb_deposit";
            this.gb_deposit.Size = new System.Drawing.Size(200, 123);
            this.gb_deposit.TabIndex = 9;
            this.gb_deposit.TabStop = false;
<<<<<<< HEAD
            this.gb_deposit.Visible = false;
=======
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            // 
            // lb_deposit
            // 
            this.lb_deposit.AutoSize = true;
            this.lb_deposit.Location = new System.Drawing.Point(29, 25);
            this.lb_deposit.Name = "lb_deposit";
            this.lb_deposit.Size = new System.Drawing.Size(133, 16);
            this.lb_deposit.TabIndex = 0;
            this.lb_deposit.Text = "Input Deposit Amount";
            // 
            // tb_depo
            // 
            this.tb_depo.Location = new System.Drawing.Point(46, 47);
            this.tb_depo.Name = "tb_depo";
            this.tb_depo.Size = new System.Drawing.Size(109, 22);
            this.tb_depo.TabIndex = 1;
            // 
            // bt_deposit2
            // 
            this.bt_deposit2.Location = new System.Drawing.Point(59, 75);
            this.bt_deposit2.Name = "bt_deposit2";
            this.bt_deposit2.Size = new System.Drawing.Size(75, 23);
            this.bt_deposit2.TabIndex = 2;
            this.bt_deposit2.Text = "Deposit";
            this.bt_deposit2.UseVisualStyleBackColor = true;
            this.bt_deposit2.Click += new System.EventHandler(this.bt_deposit2_Click);
            // 
            // gb_withdraw
            // 
            this.gb_withdraw.Controls.Add(this.lb_numdepo);
<<<<<<< HEAD
            this.gb_withdraw.Controls.Add(this.bt_withdraw2);
            this.gb_withdraw.Controls.Add(this.label4);
            this.gb_withdraw.Controls.Add(this.textBox2);
            this.gb_withdraw.Controls.Add(this.lb_withdraw);
            this.gb_withdraw.Location = new System.Drawing.Point(460, 229);
=======
            this.gb_withdraw.Controls.Add(this.button1);
            this.gb_withdraw.Controls.Add(this.label4);
            this.gb_withdraw.Controls.Add(this.textBox2);
            this.gb_withdraw.Controls.Add(this.lb_withdraw);
            this.gb_withdraw.Location = new System.Drawing.Point(526, 217);
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.gb_withdraw.Name = "gb_withdraw";
            this.gb_withdraw.Size = new System.Drawing.Size(200, 161);
            this.gb_withdraw.TabIndex = 10;
            this.gb_withdraw.TabStop = false;
<<<<<<< HEAD
            this.gb_withdraw.Visible = false;
            // 
            // bt_withdraw2
            // 
            this.bt_withdraw2.Location = new System.Drawing.Point(59, 109);
            this.bt_withdraw2.Name = "bt_withdraw2";
            this.bt_withdraw2.Size = new System.Drawing.Size(75, 23);
            this.bt_withdraw2.TabIndex = 2;
            this.bt_withdraw2.Text = "Deposit";
            this.bt_withdraw2.UseVisualStyleBackColor = true;
            this.bt_withdraw2.Click += new System.EventHandler(this.bt_withdraw2_Click);
=======
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 109);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Deposit";
            this.button1.UseVisualStyleBackColor = true;
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(46, 81);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(109, 22);
            this.textBox2.TabIndex = 1;
            // 
            // lb_withdraw
            // 
            this.lb_withdraw.AutoSize = true;
            this.lb_withdraw.Location = new System.Drawing.Point(29, 59);
            this.lb_withdraw.Name = "lb_withdraw";
            this.lb_withdraw.Size = new System.Drawing.Size(141, 16);
            this.lb_withdraw.TabIndex = 0;
            this.lb_withdraw.Text = "Input Withdraw Amount";
            // 
            // lb_numdepo
            // 
            this.lb_numdepo.AutoSize = true;
            this.lb_numdepo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_numdepo.Location = new System.Drawing.Point(117, 29);
            this.lb_numdepo.Name = "lb_numdepo";
            this.lb_numdepo.Size = new System.Drawing.Size(20, 22);
            this.lb_numdepo.TabIndex = 6;
            this.lb_numdepo.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Balance";
            // 
<<<<<<< HEAD
=======
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(44, 298);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(392, 150);
            this.dataGridView1.TabIndex = 11;
            // 
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
<<<<<<< HEAD
=======
            this.Controls.Add(this.dataGridView1);
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.Controls.Add(this.gb_withdraw);
            this.Controls.Add(this.gb_deposit);
            this.Controls.Add(this.gb_balance);
            this.Controls.Add(this.gb_Register);
            this.Controls.Add(this.gb_mainpage);
            this.Controls.Add(this.lb_Title);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_mainpage.ResumeLayout(false);
            this.gb_mainpage.PerformLayout();
            this.gb_Register.ResumeLayout(false);
            this.gb_Register.PerformLayout();
            this.gb_balance.ResumeLayout(false);
            this.gb_balance.PerformLayout();
            this.gb_deposit.ResumeLayout(false);
            this.gb_deposit.PerformLayout();
            this.gb_withdraw.ResumeLayout(false);
            this.gb_withdraw.PerformLayout();
<<<<<<< HEAD
=======
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Title;
        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.GroupBox gb_mainpage;
        private System.Windows.Forms.Button bt_register;
        private System.Windows.Forms.GroupBox gb_Register;
        private System.Windows.Forms.TextBox tb_username2;
        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.TextBox tb_password2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox gb_balance;
        private System.Windows.Forms.Label lb_number;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button bt_logout;
        private System.Windows.Forms.Button bt_withdraw;
        private System.Windows.Forms.Button bt_deposit;
        private System.Windows.Forms.GroupBox gb_deposit;
        private System.Windows.Forms.Label lb_deposit;
        private System.Windows.Forms.Button bt_deposit2;
        private System.Windows.Forms.TextBox tb_depo;
        private System.Windows.Forms.GroupBox gb_withdraw;
        private System.Windows.Forms.Label lb_numdepo;
<<<<<<< HEAD
        private System.Windows.Forms.Button bt_withdraw2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lb_withdraw;
=======
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lb_withdraw;
        private System.Windows.Forms.DataGridView dataGridView1;
>>>>>>> 1638394202772fc9f861513b794143d97f0b7a7a
    }
}

